# Shiny Application to View Models - changing variables
# and viewing added variable plots

## Try it out!